class ItemModel {
  String image;
  String jpName;
  String enName;
  String sound;
  ItemModel({
    required this.image,
    required this.jpName,
    required this.enName,
    required this.sound,
  });
}
